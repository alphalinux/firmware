char initrd_data[1];
int initrd_len = 0;
