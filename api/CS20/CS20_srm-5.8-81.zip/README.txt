API Networks Inc.

CS20 Firmware (SRM) Update Kit



version 61-0028-4B



Contents



CS20 Flash Loadable Driver v1.0 (61-0060-2A)

CS20 SROM 833MHz EV68 v2.5.2 (64-0027-5A)

CS20 NVRAM Defaults (61-0064-1A)

CS20 Debug Monitor (61-0030-1A)

CS20 Alpha Diagnostics v1.4-9 (61-0056-3E)

CS20 SRM Console v5.8-1.81 (61-0055-7A)



This update will overwrite the following ranges 

of the CS20 system flash ROM:



Address Range      New Contents

Base     End

0x00000  0x10000    SROM 833MHz EV68

0x40000  0x50000    SRM NVRAM environment variables

0x50000  0x80000    Alpha Diagnostics

0x90000  0x140000   SRM Console

0x170000 0x1B0000   Debug Monitor







Instructions



Run this program:



1) to see the manifest of the update kit



./upgflash -info   



2) to perform the update



.upgflash -upgrade



You must being running with superuser privileges to 

load the Flash driver and open the system Flash 

ROM for writing. 



