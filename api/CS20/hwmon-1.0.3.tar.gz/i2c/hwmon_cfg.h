#ifndef HWMON__HWMON_CFG_H__LOADED
#define HWMON__HWMON_CFG_H__LOADED
/*
       Copyright (c) 2001, Alpha Processor, Inc.

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *-------------------------------------------------------------------*/
/*
 * $Author: ghost $
 * $Revision: 1.7 $
 * $Id: hwmon_cfg.h,v 1.7 2001/04/24 20:27:36 ghost Exp $
 */

#include "listmgr.h"

#define CONFIG_FILE_NAME "/etc/hwmon.conf"

/* Open the configuration file (statically(?) defined above) and parse it */
int parse_cfg( void );


typedef unsigned char address_t;

/*------------------------------------------------------------------------*/
/* PARAMETERS - Attributes relating to sensors; the smallest pieces of data */

/* Everything that can be described about volt sensors */
enum volt_param_types { VOLT_NOM, VOLT_MIN, VOLT_MAX };

typedef float volt_data_t;

typedef struct
{
    char info;
    volt_data_t data;
} volt_param_t;


/* Everything that can be described about fan sensors */
enum fan_param_types { FAN_NOM, FAN_MIN };

typedef unsigned short fan_data_t;

typedef struct
{
    char info;
    fan_data_t data;
} fan_param_t;



/* Everything that can be described about temperature sensors */
enum temp_param_types { TEMP_MAX, TEMP_HYST };

typedef float temp_data_t;

typedef struct
{
    char info;
    temp_data_t data;
} temp_param_t;



/* Lists of sensor info */
typedef union {
    temp_param_t temp;
    fan_param_t fan;
    volt_param_t volt;
} param_t;




/*------------------------------------------------------------------------*/
/* SENSORS - a measured quantity. */

enum sensor_types { SENSOR_TEMP, SENSOR_FAN, SENSOR_VOLT };
enum sensor_stats { SENSOR_NORMAL, SENSOR_BROKEN, SENSOR_ALERT };

typedef struct {
    char type;			/* an enum sensor_types value */
    char stat;			/* sensor status, normal, broken, alert */
    address_t addr;		/* dev-specific location within the device */
    const char *desc;		/* a string description of the quantity */
    list_t *P;			/* Parameters for the measured device */
} sensor_t;



/*------------------------------------------------------------------------*/
/* DEVICES - a chip that may contain any number of sensors */

typedef struct { 
    const char *desc;		/* Friendly name for describing this device */
    const char *modname;	/* OS-format name (also name of first module) */
    address_t addr;		/* I2C bus address (bit 0 is read/write)*/
    list_t *M;			/* Device Driver module requirements */
    list_t *S;			/* Sensors configured on this device */
} device_t;


/*------------------------------------------------------------------------*/
/* BUSES - a network linking any number of devices */

typedef struct {
    const char *desc;		/* Friendly name for this bus */
    list_t *M;			/* Bus Driver module requirements */
    list_t *D;			/* Devices on this bus */
} bus_t;


/* If we parse successfully, we get everything setup and the bus info is here */
extern list_t *i2c_buses;
extern list_t *i2c_toplevel_modules;
extern char *i2c_shutdown_command;

/*------------------------------------------------------------------------*/
#endif	/* HWMON__HWMON_CFG_H__LOADED */
