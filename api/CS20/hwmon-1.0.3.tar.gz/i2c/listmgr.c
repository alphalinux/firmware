/*---------------------------------------------------------------------
       Copyright (c) 2001, Alpha Processor, Inc.

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *-------------------------------------------------------------------*/
/* Simple list-management module.
 * $Revision: 1.3 $
 * $Author: ghost $
 */

#include <stdio.h>
#include <stdlib.h>

#include "listmgr.h"


/* If passed a NULL entity, we return a NULL list container pointer */
list_t *makelist( void *S )
{
    list_t *L=malloc( sizeof( list_t ) );
    if ( L == NULL )
    {
	/* Should we be exiting without the hwmon daemon saying goodbye? */
	fprintf( stderr, "ALLOC FAILED for new list entry!\n" );
	exit( -1 );
    }

    L->L = S;
    L->next = NULL;
    return L;
}


/* Add another datapoint to the list, allocating heap space for its list_t */
list_t *list_add( list_t *List, void *val )
{
    list_t *L = makelist( val );
    L->next = List;
    return L;
}


/* Calculate the length of a list */
size_t list_len( list_t *L )
{
    size_t len=0;
    while ( L != NULL )
    {
	len++;
	L=L->next;
    }
    return len;
}

/* Operate on the data at every point on the list (if not NULL) */
/* The operator type is void ()(void *) for easy typecasting */
void list_act( list_t *L, list_operator_t *A )
{
    while( L != NULL )
    {
        if ( L->L != NULL )
                A( L->L );
        L = L->next;
    }
}

list_t * list_getnext( list_t *L )
{
    if ( L != NULL )
        return L->next;
    return 0;
}


/* This list library, when making a list, puts the latest addition to the
 * head of the list.  If you need an ordered list in the other order, 
 * here's a reversing function.
 */
list_t *list_rev( list_t *L )
{
    list_t *tmp, *head=NULL;

    while( L != NULL )
    {
	tmp = L->next;
	L->next = head;		/* add to the head of the list, make new head */
	head = L;

	/* The next list item to be reversed */
	L = tmp;
    }
    return head;
}


/* Join two lists, returning the joined result.  This code has the property
 * that the destination list (which comes second) is preserved, and the 
 * source list is reversed.
 *
 * It is important that this ordering is preserved in any reimplementation.
 */

list_t *list_join( list_t *src, list_t *dest )
{
    list_t *head = dest;
    list_t *tmp;

    while( src != NULL )
    {
	tmp = src;
	src = src->next;
	tmp->next = head;
	head = tmp;
    }

    return head;
}

