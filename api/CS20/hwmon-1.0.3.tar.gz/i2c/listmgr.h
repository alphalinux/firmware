#ifndef HWMON__LISTMGR_H__LOADED
#define HWMON__LISTMGR_H__LOADED
/*---------------------------------------------------------------------
       Copyright (c) 2001, Alpha Processor, Inc.

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *-------------------------------------------------------------------*/
/* Simple list management interface
 * $Id: listmgr.h,v 1.4 2001/04/24 20:27:36 ghost Exp $
 * $Author: ghost $
 */


typedef struct _list
{
    void *L;
    struct _list *next;
} list_t;

typedef void list_operator_t( void * );



/* S may point to NULL to create a list node with NULL data pointer
 * (this will be handled OK by the manipulation routines) */
list_t *makelist( void *S );


/* Create a new list entry and add it to the front of the list.
 * Note: this has the behaviour of reversing the list order when 
 * iterating along the list.
 */
list_t *list_add( list_t *List, void *val );


/* Calculate the length of a list */
size_t list_len( list_t *L );


/* Apply a function to every member of the list (except NULL-pointers) */
void list_act( list_t *L, list_operator_t *A );

/* To traverse the list */
list_t * list_getnext( list_t *L );

/* This list library, when making a list, puts the latest addition to the
 * head of the list.  If you need an ordered list in the other order, 
 * here's a reversing function.
 */
list_t *list_rev( list_t *L );


/* Join two lists, returning the joined result.  This code has the property
 * that the destination list (which comes second) is preserved, and the 
 * source list is reversed.
 */
list_t *list_join( list_t *src, list_t *dest );

#define list_getatom(List) (List->L)

/*------------------------------------------------------------------------*/
#endif	/* HWMON__LISTMGR_H__LOADED */
