Known issues with the UP1000 system:

1. 2x AGP card:
        a. At the present time, 2x AGP driver for Linux is not available so 2x mode has not been tested.
        b. The following cards have been used in 1x AGP mode: cards with Permedia-2 controller: Fire
	GL1000, ELSA Synergy, E&S, Matrox Millenium G200 and Stealth 2000.
        c. 3Dfx Rage Pro Turbo card does not work because the option ROM on the AGP card is
	not properly emulated by Alpha BIOS.

2. Clock:
	The clock program may be unable to correctly get the data on every boot. To fix this add
	the '-F' flag to the clock program on boot. For more information please see:
	http://bugs.alpha-processor.com/show_bug.cgi?id=7

