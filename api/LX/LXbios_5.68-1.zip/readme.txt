This directory contains AlphaBIOS for the AlphaPC 164LX. To update the 
firmware on an AlphaPC 164LX, enter the AlphaBIOS setup utility and
choose "AlphaBIOS Upgrade..."

------------------------
 Supported boot devices
------------------------
With the firmware on this diskette, Windows NT can be booted from an IDE
disk or a disk connected to an Adaptec AHA-294x/394x, or SYMBIOS 8xx 
SCSI controller.  Windows NT can be installed from IDE, AHA-294x/394x,
or SYMBIOS 8xx.

Once Windows NT is running, any SCSI controller on the HCL can be used for 
non-boot disks.

------------------------
Known Issues
------------------------
SMC EtherPower II 
 - The SMC EtherPower II Card worked on Rev B AlphaPC 164LX and does not
   work on Rev C AlphaPC 164LX systems. The problem is that the system
   will hang in AlphaBIOS while trying to boot Windows NT.

Sound Cards
 - The Ensonic AudioPCI Card based on the ES1370 chip causes Windows NT
   to hang once the Ensonic AudioPCI driver is loaded. The SoundBlaster
   PCI64 is an identical card to the Ensonic AudioPCI and is expected
   to exhibit the same problem.

Not acknowledging HDD while installing NT
 - There might be an error indicating that the system cannot find appropriate disk space for NT.
  This is caused by garbage data remaining in the environment setup area and  can be solved by 
  erasing all the data in "Utilities->Os selection setup" in AlphaBIOS setup screen.


